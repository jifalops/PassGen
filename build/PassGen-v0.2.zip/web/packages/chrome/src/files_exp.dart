
library chrome.src.files_exp;

export 'dart:html' show
    Blob,
    DirectoryEntry, DirectoryReader,
    Entry, EventTarget,
    File, FileEntry, FileError, FileReader, FileSystem, FileWriter,
    Metadata,
    ProgressEvent;

export 'files.dart' show ChromeFileEntry;
